import render from "./teacherRender.js";
render(
        <div>Hello DH2642 student!</div>,
    document.getElementById('root')
);    


    
