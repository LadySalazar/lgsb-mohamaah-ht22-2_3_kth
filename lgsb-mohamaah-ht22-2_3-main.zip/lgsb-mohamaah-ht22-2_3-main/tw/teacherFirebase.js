const firebase= require("firebase/app").default;
require('firebase/database');

window.firebase=firebase;
